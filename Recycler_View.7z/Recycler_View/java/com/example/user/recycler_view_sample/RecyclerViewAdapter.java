package com.example.user.recycler_view_sample;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.Adapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class RecyclerViewAdapter extends Adapter<RecyclerViewAdapter.MyViewHolder>{

    private Context context ;
    private List<holder> mData ;


    public RecyclerViewAdapter(Context context,List<holder> mData)
    {
        this.context = context;
        this.mData = mData;
    }



    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType)
    {

        View view ;
        LayoutInflater mInflater = LayoutInflater.from(context);
        view = mInflater.inflate(R.layout.profiletype_card_design,parent,false);
        return new MyViewHolder(view);

    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position)
    {

        holder.Name.setText(mData.get(position).getName());// to create card listener use get(position)
        holder.Caption.setText(mData.get(position).getCaption());
        // Bitmap bmap = BitmapFactory.decodeResource(Resources.getSystem(),Integer.valueOf());
        //oundedBitmapDrawable dr = RoundedBitmapDrawableFactory.create(Resources.getSystem(),holder.img1);




        holder.img1.setImageResource(mData.get(position).getImage1());
        holder.img2.setImageResource(mData.get(position).getImage2());



    }

    @Override
    public int getItemCount()
    {
        return mData.size();
    }



    public class MyViewHolder extends RecyclerView.ViewHolder
    {

        TextView Name, Caption;
        ImageView img1,img2;
        CardView cardView ;

        public MyViewHolder(View itemView)
        {
            super(itemView);

            Name = (TextView) itemView.findViewById(R.id.textView2);
            Caption = (TextView) itemView.findViewById(R.id.textView5);
            img1=itemView.findViewById(R.id.imageView1);
            img2=itemView.findViewById(R.id.imageView2);


        }

    }
}