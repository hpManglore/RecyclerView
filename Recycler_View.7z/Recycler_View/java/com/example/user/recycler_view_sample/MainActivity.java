package com.example.user.recycler_view_sample;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<holder> list ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = new ArrayList<>();

        list.add(new holder("Iron-Man",R.drawable.iman,R.drawable.re,"I am Iron man"));
        list.add(new holder("Hulk",R.drawable.hulk,R.drawable.re,"I am Incredible Hulk..The strongest avenger"));
        list.add(new holder("Captain-America",R.drawable.america,R.drawable.node,"I am Steve Rogers "));
        list.add(new holder("Spider Man",R.drawable.spiderman,R.drawable.re,"I am Peter Parker"));
        list.add(new holder("Ant-Man",R.drawable.antman,R.drawable.node,"I am..."));
        /*list.add(new holder("mojo",R.drawable.squirrel,R.drawable.tank,"Squ2"));
        list.add(new holder("motu",R.drawable.babler,R.drawable.tank,"bb"));
        list.add(new holder("Patlu",R.drawable.squirrel,R.drawable.tank,"sq3"));
        list.add(new holder("Tom",R.drawable.egret1,R.drawable.tank,"eg3"));*/


        RecyclerView myrv = (RecyclerView) findViewById(R.id.recyclerview_id);

        RecyclerViewAdapter myAdapter = new RecyclerViewAdapter(this,list);

        myrv.setLayoutManager(new LinearLayoutManager(this));
        myrv.setAdapter(myAdapter);




    }
}
