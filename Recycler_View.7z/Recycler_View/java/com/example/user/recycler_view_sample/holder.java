package com.example.user.recycler_view_sample;

public class holder {
    String name,caption;
    int Image1,Image2;

    public holder()
    {
    }

    public holder(String names, int image1, int image2,String captions)
    {
        name=names;
        Image1=image1;
        Image2=image2;
        caption=captions;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public int getImage1() {
        return Image1;
    }

    public void setImage1(int image1) {
        Image1 = image1;
    }

    public int getImage2() {
        return Image2;
    }

    public void setImage2(int image2) {
        Image2 = image2;
    }
}







